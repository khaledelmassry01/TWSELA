import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/login.page.js';

test.describe('Courier - Manifest and Delivery', () => {
  let loginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    
    // تسجيل الدخول كمندوب (البيانات الصحيحة من Database)
    await loginPage.goto();
    await loginPage.login('01023782586', '150620KkZz@#$');
    await loginPage.waitForNavigation();
  });

  test('TC-C001: Courier can view dashboard', async ({ page }) => {
    await expect(page).toHaveURL(/courier\/dashboard/);
    await expect(page).toHaveTitle(/لوحة التحكم|Dashboard/);
  });

  test('TC-C002: Courier can view manifest', async ({ page }) => {
    await page.goto('/courier/manifest.html');
    
    // التحقق من وجود قائمة المنافيست
    const manifestList = page.locator('.manifest-list, table.manifest-table');
    await expect(manifestList).toBeVisible();
  });

  test('TC-C003: Courier can update shipment status to PICKED_UP', async ({ page }) => {
    await page.goto('/courier/dashboard.html');
    
    // اختيار أول شحنة
    const firstShipment = page.locator('.shipment-item:first-child, tbody tr:first-child').first();
    
    if (await firstShipment.isVisible()) {
      // انقر على زر تحديث الحالة
      const updateButton = firstShipment.locator('button:has-text("تحديث"), button.update-status');
      
      if (await updateButton.isVisible()) {
        await updateButton.click();
        
        // اختيار الحالة الجديدة
        const statusSelect = page.locator('select[name="status"], .status-select');
        await statusSelect.selectOption('PICKED_UP');
        
        // تأكيد التحديث
        const confirmButton = page.locator('button:has-text("تأكيد"), button[type="submit"]');
        await confirmButton.click();
        
        // التحقق من رسالة النجاح
        const successMessage = page.locator('.success-message, .alert-success');
        await expect(successMessage).toBeVisible({ timeout: 5000 });
      }
    }
  });

  test('TC-C004: Courier can generate manifest PDF', async ({ page }) => {
    await page.goto('/courier/manifest.html');
    
    // انقر على زر توليد PDF
    const pdfButton = page.locator('button:has-text("PDF"), button:has-text("طباعة"), .generate-pdf');
    
    if (await pdfButton.isVisible()) {
      // مراقبة طلب تحميل PDF
      const downloadPromise = page.waitForEvent('download');
      await pdfButton.click();
      const download = await downloadPromise;
      
      // التحقق من اسم الملف
      expect(download.suggestedFilename()).toMatch(/manifest.*\.pdf/i);
    }
  });

  test('TC-C005: Courier can filter shipments by zone', async ({ page }) => {
    await page.goto('/courier/dashboard.html');
    
    const zoneFilter = page.locator('select[name="zone"], .zone-filter');
    
    if (await zoneFilter.isVisible()) {
      await zoneFilter.selectOption({ index: 1 });
      await page.waitForTimeout(1000);
      
      // التحقق من تطبيق الفلتر
      const shipments = page.locator('.shipment-item, tbody tr');
      const count = await shipments.count();
      expect(count).toBeGreaterThanOrEqual(0);
    }
  });

  test('TC-C006: Courier cannot access merchant endpoints', async ({ page }) => {
    // محاولة الوصول لصفحة التاجر
    const response = await page.goto('/merchant/create-shipment.html');
    
    // يجب إعادة التوجيه أو عرض خطأ
    expect(response?.status()).not.toBe(200);
  });
});
