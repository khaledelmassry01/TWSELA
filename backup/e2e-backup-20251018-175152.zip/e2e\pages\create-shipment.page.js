// Page Object Model for Create Shipment Page

export class CreateShipmentPage {
  constructor(page) {
    this.page = page;
    this.recipientNameInput = page.locator('input[name="recipientName"]');
    this.recipientPhoneInput = page.locator('input[name="recipientPhone"]');
    this.recipientAddressInput = page.locator('textarea[name="recipientAddress"], input[name="recipientAddress"]');
    this.zoneSelect = page.locator('select[name="zoneId"]');
    this.codAmountInput = page.locator('input[name="codAmount"]');
    this.descriptionInput = page.locator('textarea[name="description"], input[name="description"]');
    this.notesInput = page.locator('textarea[name="notes"]');
    this.submitButton = page.locator('button[type="submit"]:has-text("إنشاء"), button:has-text("حفظ")');
    this.successMessage = page.locator('.success-message, .alert-success');
  }

  async goto() {
    await this.page.goto('/merchant/create-shipment.html');
  }

  async fillShipmentForm(data) {
    await this.recipientNameInput.fill(data.recipientName);
    await this.recipientPhoneInput.fill(data.recipientPhone);
    await this.recipientAddressInput.fill(data.recipientAddress);
    await this.zoneSelect.selectOption({ value: data.zoneId.toString() });
    await this.codAmountInput.fill(data.codAmount.toString());
    
    if (data.description) {
      await this.descriptionInput.fill(data.description);
    }
    
    if (data.notes) {
      await this.notesInput.fill(data.notes);
    }
  }

  async submitForm() {
    await this.submitButton.click();
  }

  async isSuccessMessageVisible() {
    return await this.successMessage.isVisible();
  }

  async getSuccessMessage() {
    return await this.successMessage.textContent();
  }
}
