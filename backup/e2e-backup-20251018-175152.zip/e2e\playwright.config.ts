// @ts-nocheck
// ملاحظة: يتطلب تثبيت التبعيات أولاً: npm ci
import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright Configuration for Twsela E2E Tests
 * See https://playwright.dev/docs/test-configuration
 */
export default defineConfig({
  testDir: './tests',
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html', { outputFolder: 'reports/html', open: 'never' }],
    ['junit', { outputFile: 'reports/junit/results.xml' }],
    ['json', { outputFile: 'reports/json/results.json' }],
    ['list']
  ],
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    ignoreHTTPSErrors: true, // للتطوير المحلي مع SSL self-signed
    locale: 'ar-SA',
    timezoneId: 'Asia/Riyadh',
  },

  projects: [
    {
      name: 'chromium',
      use: { 
        ...devices['Desktop Chrome'],
        viewport: { width: 1920, height: 1080 }
      },
    },
    {
      name: 'firefox',
      use: { 
        ...devices['Desktop Firefox'],
        viewport: { width: 1920, height: 1080 }
      },
    },
    {
      name: 'webkit',
      use: { 
        ...devices['Desktop Safari'],
        viewport: { width: 1920, height: 1080 }
      },
    },
    {
      name: 'mobile-chrome',
      use: { 
        ...devices['Pixel 5']
      },
    },
    {
      name: 'mobile-safari',
      use: { 
        ...devices['iPhone 13']
      },
    },
  ],

  // webServer disabled - Backend already running
  // webServer: {
  //   command: 'echo "تأكد من تشغيل Backend و Frontend قبل الاختبار"',
  //   url: 'https://localhost:8443',
  //   reuseExistingServer: !process.env.CI,
  //   ignoreHTTPSErrors: true,
  //   timeout: 120000,
  // },
});
