# Twsela E2E Tests - Playwright

## نظرة عامة
اختبارات End-to-End شاملة لنظام Twsela باستخدام Playwright مع دعم كامل للعربية و RTL.

## التثبيت

### المتطلبات
- Node.js (LTS) v18+
- npm أو yarn

### خطوات التثبيت
```powershell
cd testing/e2e
npm install
npx playwright install
```

## البنية

```
testing/e2e/
├── tests/              # الاختبارات منظمة حسب الدور
│   ├── owner/         # اختبارات Owner
│   ├── admin/         # اختبارات Admin
│   ├── merchant/      # اختبارات Merchant
│   ├── courier/       # اختبارات Courier
│   └── warehouse/     # اختبارات Warehouse
├── pages/             # Page Object Models
│   ├── login.page.js
│   ├── merchant-dashboard.page.js
│   └── create-shipment.page.js
├── reports/           # تقارير الاختبار
│   ├── html/
│   ├── junit/
│   └── json/
├── playwright.config.ts
└── package.json
```

## تشغيل الاختبارات

### جميع الاختبارات
```powershell
npm test
```

### اختبارات دور محدد
```powershell
npm run test:owner
npm run test:merchant
npm run test:courier
npm run test:warehouse
npm run test:admin
```

### وضع Debug
```powershell
npm run test:debug
```

### واجهة UI التفاعلية
```powershell
npm run test:ui
```

### مع عرض المتصفح (Headed)
```powershell
npm run test:headed
```

### متصفح محدد
```powershell
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit
```

### اختبار محدد
```powershell
npx playwright test tests/merchant/shipment-management.spec.js
```

## التقارير

### عرض التقرير HTML
```powershell
npm run report
```

التقارير المتاحة:
- **HTML Report**: `reports/html/index.html`
- **JUnit XML**: `reports/junit/results.xml` (للتكامل مع CI/CD)
- **JSON**: `reports/json/results.json`

## Page Object Models

نستخدم نمط Page Object Model لتنظيم الكود:

### مثال: LoginPage
```javascript
import { LoginPage } from '../pages/login.page.js';

const loginPage = new LoginPage(page);
await loginPage.goto();
await loginPage.login('user@example.com', 'password');
```

### مثال: MerchantDashboardPage
```javascript
import { MerchantDashboardPage } from '../pages/merchant-dashboard.page.js';

const dashboard = new MerchantDashboardPage(page);
await dashboard.goto();
await dashboard.clickCreateShipment();
```

## الاختبارات المتوفرة

### Merchant Tests (TC-M001 إلى TC-M008)
- ✅ عرض لوحة التحكم
- ✅ إنشاء شحنة جديدة
- ✅ التحقق من الحقول المطلوبة
- ✅ البحث في الشحنات
- ✅ الفلترة حسب الحالة
- ✅ عرض تفاصيل الشحنة
- ✅ دعم RTL والعربية
- ✅ التصميم المتجاوب

### Courier Tests (TC-C001 إلى TC-C006)
- ✅ عرض لوحة التحكم
- ✅ عرض المنافيست
- ✅ تحديث حالة الشحنة
- ✅ توليد PDF للمنافيست
- ✅ الفلترة حسب المنطقة
- ✅ التحقق من صلاحيات RBAC

### Owner Tests (TC-O001 إلى TC-O010)
- ✅ عرض لوحة التحكم
- ✅ إدارة التجار (عرض، إضافة)
- ✅ إدارة المناطق (عرض، إضافة)
- ✅ عرض التقارير
- ✅ إنشاء تقرير الشحنات
- ✅ إعدادات التسعير
- ✅ المدفوعات
- ✅ الوصول لجميع الشحنات

## التكوين

### playwright.config.ts
يتضمن:
- دعم متصفحات متعددة (Chrome, Firefox, Safari)
- دعم الموبايل (Pixel 5, iPhone 13)
- تقارير متعددة (HTML, JUnit, JSON)
- Screenshots عند الفشل
- فيديو للاختبارات الفاشلة
- دعم SSL self-signed للتطوير المحلي
- Locale عربي (ar-SA)
- منطقة زمنية الرياض

### متغيرات البيئة
```env
BASE_URL=https://localhost:8443
OWNER_USERNAME=owner@twsela.com
OWNER_PASSWORD=OwnerPass123!
MERCHANT_USERNAME=merchant@test.com
MERCHANT_PASSWORD=MerchantPass123!
```

## أفضل الممارسات

### 1. استخدام Page Objects
```javascript
// ❌ خطأ
await page.click('button[type="submit"]');

// ✅ صحيح
await loginPage.loginButton.click();
```

### 2. انتظار العناصر
```javascript
// ❌ خطأ
await page.waitForTimeout(5000);

// ✅ صحيح
await expect(element).toBeVisible();
```

### 3. اختبارات مستقلة
كل اختبار يجب أن:
- يعمل بشكل مستقل
- ينظف بعد نفسه
- لا يعتمد على ترتيب التنفيذ

### 4. استخدام Locators الموثوقة
```javascript
// ❌ تجنب
page.locator('.btn-primary')

// ✅ أفضل
page.locator('button[type="submit"]')
page.locator('button:has-text("تسجيل الدخول")')
```

## التكامل مع CI/CD

### GitHub Actions
```yaml
- name: Run E2E Tests
  run: |
    cd testing/e2e
    npm ci
    npx playwright install --with-deps
    npm test
```

### نتائج الاختبار
- ينتج JUnit XML للتكامل مع أدوات CI
- Screenshots للاختبارات الفاشلة
- فيديوهات للتحليل

## استكشاف الأخطاء

### الاختبارات تفشل بسبب SSL
```javascript
// في playwright.config.ts
use: {
  ignoreHTTPSErrors: true,
}
```

### Elements لا تظهر
```powershell
# استخدم وضع Debug لمشاهدة المتصفح
npm run test:debug
```

### تشغيل بطيء
```javascript
// زيادة timeout في الاختبار
test.setTimeout(60000); // 60 ثانية
```

## دعم اللغة العربية

### التحقق من RTL
```javascript
test('Verify RTL support', async ({ page }) => {
  const dir = await page.locator('html').getAttribute('dir');
  expect(dir).toBe('rtl');
});
```

### التحقق من الخطوط العربية
```javascript
test('Verify Arabic fonts', async ({ page }) => {
  const fontFamily = await page.locator('body').evaluate(
    el => window.getComputedStyle(el).fontFamily
  );
  expect(fontFamily).toContain('Noto Sans Arabic');
});
```

## إضافة اختبارات جديدة

1. أنشئ ملف spec جديد:
```javascript
// tests/role/feature.spec.js
import { test, expect } from '@playwright/test';

test.describe('Feature Name', () => {
  test('TC-XXX: Test description', async ({ page }) => {
    // اختبارك هنا
  });
});
```

2. إذا لزم، أنشئ Page Object جديد:
```javascript
// pages/feature.page.js
export class FeaturePage {
  constructor(page) {
    this.page = page;
    // locators هنا
  }
  
  async performAction() {
    // أفعال هنا
  }
}
```

3. شغّل الاختبار:
```powershell
npx playwright test tests/role/feature.spec.js
```

## الموارد

- [Playwright Documentation](https://playwright.dev)
- [Best Practices](https://playwright.dev/docs/best-practices)
- [Page Object Model](https://playwright.dev/docs/pom)
- TWSELA_READINESS_TEST_PLAN_AR.md

## المساهمة

عند إضافة اختبارات جديدة:
1. اتبع نمط Page Object Model
2. أضف تعليقات توضيحية
3. حدّث هذا README
4. تأكد من عمل الاختبار في CI
