// Page Object Model for Merchant Dashboard

export class MerchantDashboardPage {
  constructor(page) {
    this.page = page;
    this.createShipmentButton = page.locator('a[href*="create-shipment"], button:has-text("إنشاء شحنة")');
    this.shipmentsTable = page.locator('table.shipments-table, .shipments-list');
    this.searchInput = page.locator('input[type="search"], input[placeholder*="بحث"]');
    this.statusFilter = page.locator('select[name="status"]');
  }

  async goto() {
    await this.page.goto('/merchant/dashboard.html');
  }

  async clickCreateShipment() {
    await this.createShipmentButton.click();
  }

  async searchShipment(query) {
    await this.searchInput.fill(query);
    await this.page.keyboard.press('Enter');
  }

  async filterByStatus(status) {
    await this.statusFilter.selectOption(status);
  }

  async getShipmentCount() {
    const rows = await this.shipmentsTable.locator('tbody tr, .shipment-item').count();
    return rows;
  }
}
