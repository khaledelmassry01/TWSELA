import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/login.page.js';

test.describe('Owner - System Administration', () => {
  let loginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    
    // تسجيل الدخول كمالك (البيانات الصحيحة من Database)
    await loginPage.goto();
    await loginPage.login('01023782584', '150620KkZz@#$');
    await loginPage.waitForNavigation();
  });

  test('TC-O001: Owner can view dashboard', async ({ page }) => {
    await expect(page).toHaveURL(/owner\/dashboard/);
    await expect(page).toHaveTitle(/لوحة التحكم|Dashboard/);
  });

  test('TC-O002: Owner can view merchants list', async ({ page }) => {
    await page.goto('/owner/merchants.html');
    
    const merchantsTable = page.locator('table.merchants-table, .merchants-list');
    await expect(merchantsTable).toBeVisible();
  });

  test('TC-O003: Owner can create new merchant', async ({ page }) => {
    await page.goto('/owner/merchants.html');
    
    const createButton = page.locator('button:has-text("إضافة"), a:has-text("تاجر جديد")');
    
    if (await createButton.isVisible()) {
      await createButton.click();
      
      // ملء نموذج التاجر
      await page.locator('input[name="businessName"]').fill('متجر اختبار جديد');
      await page.locator('input[name="contactName"]').fill('أحمد محمد');
      await page.locator('input[name="email"]').fill('newmerchant@test.com');
      await page.locator('input[name="phone"]').fill('0501234567');
      await page.locator('input[name="address"], textarea[name="address"]').fill('الرياض');
      
      await page.locator('button[type="submit"]').click();
      
      const successMessage = page.locator('.success-message, .alert-success');
      await expect(successMessage).toBeVisible({ timeout: 5000 });
    }
  });

  test('TC-O004: Owner can view zones', async ({ page }) => {
    await page.goto('/owner/zones.html');
    
    const zonesTable = page.locator('table.zones-table, .zones-list');
    await expect(zonesTable).toBeVisible();
  });

  test('TC-O005: Owner can create new zone', async ({ page }) => {
    await page.goto('/owner/zones.html');
    
    const createButton = page.locator('button:has-text("إضافة منطقة"), a:has-text("منطقة جديدة")');
    
    if (await createButton.isVisible()) {
      await createButton.click();
      
      await page.locator('input[name="name"]').fill('منطقة اختبار');
      await page.locator('textarea[name="description"]').fill('منطقة تجريبية');
      await page.locator('input[name="basePrice"]').fill('25.00');
      await page.locator('input[name="codFee"]').fill('5.00');
      
      await page.locator('button[type="submit"]').click();
      
      const successMessage = page.locator('.success-message, .alert-success');
      await expect(successMessage).toBeVisible({ timeout: 5000 });
    }
  });

  test('TC-O006: Owner can view reports', async ({ page }) => {
    await page.goto('/owner/reports.html');
    
    await expect(page.locator('.reports-container, .report-section')).toBeVisible();
  });

  test('TC-O007: Owner can generate shipments report', async ({ page }) => {
    await page.goto('/owner/reports.html');
    
    // اختيار نطاق تاريخي
    const startDate = page.locator('input[name="startDate"]');
    const endDate = page.locator('input[name="endDate"]');
    
    if (await startDate.isVisible()) {
      await startDate.fill('2025-01-01');
      await endDate.fill('2025-12-31');
      
      const generateButton = page.locator('button:has-text("إنشاء تقرير"), button:has-text("عرض")');
      await generateButton.click();
      
      await page.waitForTimeout(2000);
      
      // التحقق من عرض البيانات
      const reportData = page.locator('.report-data, .report-table');
      await expect(reportData).toBeVisible();
    }
  });

  test('TC-O008: Owner can view pricing settings', async ({ page }) => {
    await page.goto('/owner/pricing.html');
    
    const pricingForm = page.locator('form.pricing-form, .pricing-settings');
    await expect(pricingForm).toBeVisible();
  });

  test('TC-O009: Owner can view payouts', async ({ page }) => {
    await page.goto('/owner/payouts.html');
    
    const payoutsTable = page.locator('table.payouts-table, .payouts-list');
    await expect(payoutsTable).toBeVisible();
  });

  test('TC-O010: Owner can access all shipments', async ({ page }) => {
    await page.goto('/owner/shipments.html');
    
    const shipmentsTable = page.locator('table.shipments-table, .shipments-list');
    await expect(shipmentsTable).toBeVisible();
  });
});
