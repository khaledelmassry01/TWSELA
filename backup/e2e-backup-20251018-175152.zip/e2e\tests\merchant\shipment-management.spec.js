import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/login.page.js';
import { MerchantDashboardPage } from '../../pages/merchant-dashboard.page.js';
import { CreateShipmentPage } from '../../pages/create-shipment.page.js';

test.describe('Merchant - Shipment Management', () => {
  let loginPage;
  let dashboardPage;
  let createShipmentPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new MerchantDashboardPage(page);
    createShipmentPage = new CreateShipmentPage(page);

    // تسجيل الدخول كتاجر (البيانات الصحيحة من Database)
    await loginPage.goto();
    await loginPage.login('01023782585', '150620KkZz@#$');
    await loginPage.waitForNavigation();
  });

  test('TC-M001: Merchant can view dashboard', async ({ page }) => {
    await expect(page).toHaveURL(/merchant\/dashboard/);
    await expect(page).toHaveTitle(/لوحة التحكم|Dashboard/);
    
    // التحقق من العناصر الأساسية
    await expect(dashboardPage.createShipmentButton).toBeVisible();
    await expect(dashboardPage.shipmentsTable).toBeVisible();
  });

  test('TC-M002: Merchant can create new shipment', async ({ page }) => {
    await dashboardPage.clickCreateShipment();
    await expect(page).toHaveURL(/create-shipment/);

    const shipmentData = {
      recipientName: 'أحمد محمد علي',
      recipientPhone: '0501234567',
      recipientAddress: 'الرياض، حي النخيل، شارع الملك فهد',
      zoneId: 1,
      codAmount: 250.50,
      description: 'هاتف محمول',
      notes: 'يُرجى التوصيل في المساء'
    };

    await createShipmentPage.fillShipmentForm(shipmentData);
    await createShipmentPage.submitForm();

    // التحقق من نجاح الإنشاء
    await expect(createShipmentPage.successMessage).toBeVisible({ timeout: 5000 });
    const message = await createShipmentPage.getSuccessMessage();
    expect(message).toContain('نجح');
  });

  test('TC-M003: Merchant cannot create shipment with missing required fields', async ({ page }) => {
    await dashboardPage.clickCreateShipment();
    
    // محاولة الإرسال بدون ملء الحقول
    await createShipmentPage.submitForm();
    
    // التحقق من ظهور رسائل خطأ
    const errorMessages = page.locator('.error, .invalid-feedback, .field-error');
    await expect(errorMessages.first()).toBeVisible();
  });

  test('TC-M004: Merchant can search for shipments', async ({ page }) => {
    await dashboardPage.searchShipment('أحمد');
    
    // الانتظار لتحميل النتائج
    await page.waitForTimeout(1000);
    
    // التحقق من وجود نتائج
    const count = await dashboardPage.getShipmentCount();
    expect(count).toBeGreaterThanOrEqual(0);
  });

  test('TC-M005: Merchant can filter shipments by status', async ({ page }) => {
    await dashboardPage.filterByStatus('CREATED');
    
    // الانتظار لتحميل النتائج
    await page.waitForTimeout(1000);
    
    // التحقق من تطبيق الفلتر
    const statusBadges = page.locator('.status-badge, .shipment-status');
    if (await statusBadges.count() > 0) {
      const firstStatus = await statusBadges.first().textContent();
      expect(firstStatus).toContain('CREATED');
    }
  });

  test('TC-M006: Merchant can view shipment details', async ({ page }) => {
    // انقر على أول شحنة في القائمة
    const firstShipment = dashboardPage.shipmentsTable.locator('tbody tr:first-child a, .shipment-item:first-child a').first();
    
    if (await firstShipment.isVisible()) {
      await firstShipment.click();
      
      // التحقق من الانتقال لصفحة التفاصيل
      await expect(page).toHaveURL(/shipment-details/);
      
      // التحقق من وجود معلومات الشحنة
      await expect(page.locator('.shipment-info, .shipment-details')).toBeVisible();
    }
  });

  test('TC-M007: Verify RTL and Arabic support', async ({ page }) => {
    // التحقق من اتجاه النص
    const htmlDir = await page.locator('html').getAttribute('dir');
    expect(htmlDir).toBe('rtl');
    
    // التحقق من وجود محتوى عربي
    const content = await page.textContent('body');
    expect(content).toMatch(/[\u0600-\u06FF]/); // Unicode range for Arabic
  });

  test('TC-M008: Verify responsive design on mobile', async ({ page }) => {
    // تغيير حجم المتصفح لمحاكاة الموبايل
    await page.setViewportSize({ width: 375, height: 667 });
    
    await dashboardPage.goto();
    
    // التحقق من أن العناصر الأساسية ظاهرة ومتجاوبة
    await expect(dashboardPage.createShipmentButton).toBeVisible();
  });
});
