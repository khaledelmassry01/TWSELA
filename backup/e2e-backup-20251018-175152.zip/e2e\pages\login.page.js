// Page Object Model for Login Page

export class LoginPage {
  constructor(page) {
    this.page = page;
    // استخدام phone بدلاً من email (حسب Backend)
    this.phoneInput = page.locator('input#phone, input[name="phone"]');
    this.passwordInput = page.locator('input#password, input[name="password"]');
    this.loginButton = page.locator('button[type="submit"], button:has-text("تسجيل الدخول")');
    this.errorMessage = page.locator('.error-message, .alert-danger, #errorMsg');
  }

  async goto() {
    await this.page.goto('/login.html');
  }

  async login(phone, password) {
    await this.phoneInput.fill(phone);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  async waitForNavigation() {
    await this.page.waitForURL(/dashboard/, { timeout: 5000 });
  }

  async getErrorMessage() {
    return await this.errorMessage.textContent();
  }
}
