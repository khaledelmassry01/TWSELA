# Twsela API Testing - Postman Collection

## نظرة عامة
هذا المجلد يحتوي على مجموعة Postman شاملة لاختبار جميع واجهات API في نظام Twsela.

## الملفات
- `Twsela_API_Collection.postman_collection.json` - المجموعة الرئيسية مع جميع الطلبات والاختبارات
- `Twsela_Local_Environment.postman_environment.json` - بيئة التطوير المحلية

## المزايا
- ✅ تغطية شاملة لجميع الأدوار (Owner, Admin, Merchant, Courier, Warehouse)
- ✅ اختبارات آلية للتحقق من صيغة الاستجابة القياسية
- ✅ Pre-request Scripts للحصول على JWT تلقائياً
- ✅ اختبارات RBAC والسيناريوهات السلبية
- ✅ اختبارات Pagination والـ Filtering
- ✅ توثيق كامل لكل Endpoint

## البدء السريع

### 1. استيراد في Postman
```
1. افتح Postman
2. اذهب إلى File > Import
3. اسحب الملفين JSON إلى نافذة الاستيراد
4. انقر على Import
```

### 2. تهيئة البيئة
- اختر "Twsela - Local Development" من قائمة البيئات
- تأكد من تحديث بيانات الاعتماد حسب بيئتك
- عدّل `base_url` إذا كان مختلفاً

### 3. تشغيل الاختبارات

#### يدوياً في Postman
1. اختر المجلد "Authentication"
2. شغّل "Login - Owner" (أو أي دور آخر)
3. بعد نجاح تسجيل الدخول، سيتم حفظ JWT تلقائياً
4. شغّل باقي الطلبات في المجلدات الأخرى

#### عبر Newman (CLI)
```powershell
# تثبيت Newman
npm install -g newman

# تشغيل المجموعة كاملة
newman run Twsela_API_Collection.postman_collection.json `
  -e Twsela_Local_Environment.postman_environment.json `
  -r cli,html,junit `
  --reporter-html-export reports/api-test-report.html `
  --reporter-junit-export reports/junit-report.xml

# تشغيل مجلد محدد فقط
newman run Twsela_API_Collection.postman_collection.json `
  -e Twsela_Local_Environment.postman_environment.json `
  --folder "Authentication"
```

## هيكل المجموعة

### 1. Authentication
- تسجيل الدخول لكل دور
- تجديد Token
- تسجيل الخروج

### 2. Shipments
- إنشاء شحنة (Merchant)
- عرض تفاصيل الشحنة
- قائمة الشحنات مع Pagination
- تحديث حالة الشحنة (Courier)
- تحديث جماعي للشحنات

### 3. Merchants (Owner)
- إنشاء تاجر
- قائمة التجار

### 4. Zones (Owner)
- إنشاء منطقة
- قائمة المناطق

### 5. Manifest (Courier)
- عرض منافيست المندوب
- توليد PDF للمنافيست

### 6. Reports (Owner)
- تقرير ملخص الشحنات
- تقرير أداء المندوبين

### 7. Negative Tests - RBAC
- اختبار الوصول غير المصرح به
- اختبار JWT غير صالح
- اختبار الحقول المفقودة

## الاختبارات الآلية

كل طلب يتضمن اختبارات آلية للتحقق من:
- رمز الحالة HTTP الصحيح
- صيغة الاستجابة القياسية (`success`, `message`, `data`, `errors`)
- وجود الحقول المطلوبة
- زمن الاستجابة (أقل من 3 ثواني)
- نوع المحتوى (JSON)

## متغيرات البيئة

| المتغير | الوصف | القيمة الافتراضية |
|---------|-------|-------------------|
| `base_url` | عنوان API الأساسي | `https://localhost:8443/api/v1` |
| `owner_username` | اسم مستخدم Owner | `owner@twsela.com` |
| `merchant_username` | اسم مستخدم Merchant | `merchant@test.com` |
| `courier_username` | اسم مستخدم Courier | `courier@twsela.com` |
| `warehouse_username` | اسم مستخدم Warehouse | `warehouse@twsela.com` |
| `jwt_token` | JWT الحالي (يُملأ تلقائياً) | - |

## التكامل مع CI/CD

### GitHub Actions مثال
```yaml
- name: Run API Tests
  run: |
    npm install -g newman
    newman run testing/postman/Twsela_API_Collection.postman_collection.json \
      -e testing/postman/Twsela_Local_Environment.postman_environment.json \
      -r junit,html \
      --reporter-junit-export test-results/api-tests.xml
```

## ملاحظات مهمة

### صيغة الاستجابة القياسية
جميع الـ endpoints يجب أن ترجع هذه الصيغة:
```json
{
  "success": true/false,
  "message": "رسالة توضيحية",
  "data": { /* البيانات */ },
  "errors": [] /* في حالة الأخطاء */
}
```

### تسلسل الحالات
دورة حياة الشحنة:
```
CREATED → PICKED_UP → IN_TRANSIT → DELIVERED
```

### RBAC
- Owner: وصول كامل
- Admin: إدارة النظام
- Merchant: إدارة الشحنات الخاصة
- Courier: تحديث حالة الشحنات المخصصة
- Warehouse: استلام وفرز الشحنات

## استكشاف الأخطاء

### 401 Unauthorized
- تأكد من تسجيل الدخول أولاً
- تحقق من صلاحية JWT
- جرّب تجديد Token

### 403 Forbidden
- تأكد من استخدام الدور الصحيح
- راجع صلاحيات RBAC

### SSL Certificate Errors
```powershell
# في Newman، يمكنك تعطيل التحقق من SSL (للتطوير فقط)
newman run collection.json -e environment.json --insecure
```

## التقارير

Newman يولّد تقارير بعدة صيغ:
- `cli` - عرض في الطرفية
- `html` - تقرير HTML تفاعلي
- `junit` - XML للتكامل مع CI/CD
- `json` - JSON للمعالجة البرمجية

## المساهمة

عند إضافة endpoints جديدة:
1. أضف الطلب في المجلد المناسب
2. أضف اختبارات آلية
3. وثّق المتغيرات الجديدة
4. حدّث هذا README

## الدعم

للمشاكل أو الأسئلة، راجع:
- TWSELA_READINESS_TEST_PLAN_AR.md
- SWAGGER_API_DOCUMENTATION.md
- TWSELA_COMPLETE_API_DOCUMENTATION.md
